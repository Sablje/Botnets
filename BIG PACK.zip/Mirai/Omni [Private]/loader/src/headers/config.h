#pragma once

#define HTTP_SERVER "104.248.141.0"
#define HTTP_PORT 80

#define TFTP_SERVER "104.248.141.0"
