# Unix is qbot but modified version
Thanks for purchase ^^
Qbot Botnet. Telnet botnet, most powerfull and strong botnet. requirements: 2 linux server.
